/**
 * @license
 * Copyright 2023 Google Inc.
 * SPDX-License-Identifier: Apache-2.0
 */
import debug from 'debug';
export { debug };
//# sourceMappingURL=debug.d.ts.map